package debugdemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class WrappedHashMapTest {

    @Test
    public void smokeTest() {
        WrappedHashMap map = new WrappedHashMap();
        int id = 5;
        String value = "five";
        map.put(id, value);
        Assertions.assertEquals(value, map.get(id));
    }
}
