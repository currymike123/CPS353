package exercise1;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class WidgetTest {

    @Test
    public void smokeTest() {
        Foo dependency = mock(Foo.class);
        
        // Tricky part! Remember to set up mock behavior, and to
        // use matchers (for example, anyInt) rather than specific hardcoded values.
        when(dependency.validate(anyInt())).thenReturn(true);
        
        Widget toTest = new Widget(dependency);
        int result = toTest.addNumbers(2, 3);
        
        Assertions.assertEquals(5, result);
    }
}
