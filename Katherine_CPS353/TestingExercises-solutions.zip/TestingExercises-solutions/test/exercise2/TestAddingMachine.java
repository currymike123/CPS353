package exercise2;

import java.util.Random;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestAddingMachine {

	private static final int NUM_RUNS = 100;

    @Test
	public void testSimple() {
		AddingMachine testAddingMachine = new AddingMachine();
		checkComputation(2, 3, testAddingMachine);
	}

	@Test
	public void testFuzzyAdding() {
	    // Make sure we can reproduce any failures
	    long seed = System.currentTimeMillis();
		runTestWithSeed(seed);
	}
	
	public static void main(String[] args) {
	    // Provide the seed from the failed test run
	    // Note: there are many ways to do this, but this leaves a convenient
	    // way for future devs to investigate a test failure without building
	    // any new code
	    long seed = Long.parseLong(args[0]);
	    runTestWithSeed(seed);
	}

    private static void runTestWithSeed(long seed) {
        System.out.println("Running test with seed: " + seed);
        Random rng = new Random(seed);
		AddingMachine toTest = new AddingMachine();
		
		for (int i = 0; i < NUM_RUNS; i++) {
		    int a = rng.nextInt();
		    int b = rng.nextInt();
		    checkComputation(a, b, toTest);
		}
    }
	
	private static void checkComputation(int a, int b, AddingMachine testAddingMachine) {
		long actualResult = testAddingMachine.add(a, b);
		long expectedResult = a;
		expectedResult += b;
		Assertions.assertEquals(expectedResult, actualResult);
	}
}
