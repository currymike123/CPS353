package exercise2;

public class AddingMachine {
	public long add(int a, int b) {
	    
	    // Found the bug! Integer overflow in the test prompts us to
	    // look more closely at this line, and realize that the implicit cast
	    // to a long for the return value happens *after* the addition.
	    //
	    // Note: while the second set of parentheses is technically redundant,
	    // given that we're already fixing a bug relating to exactly when a cast happens,
	    // it's good to be extremely explicit - both to reduce the risk that we've forgotten
	    // whether casting takes precedence over addition, and to avoid future developers needing
	    // to go look that up to see if there's a bug here
		return ((long)a) + b;
	}
}
