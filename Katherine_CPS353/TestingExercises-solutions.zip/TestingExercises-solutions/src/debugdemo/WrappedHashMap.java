package debugdemo;

import java.util.HashMap;
import java.util.Map;

public class WrappedHashMap {
    private Map<Integer, String> data;
    
    // Bug fixed! Pro tip: never rely on default values
    // for primitive types, so you'll always be in the habit of intializing
    // fields
    private boolean needToInitialize = true;

    public String get(int id) {
        if (needToInitialize) {
            initalize();
            needToInitialize = false;
        }
        
        return data.get(id);
    }
    
    public void put(int id, String value) {
        if (needToInitialize) {
            initalize();
            needToInitialize = false;
        }
        
        data.put(id, value);
    }
    
    private void initalize() {
        int initialCapacity = 10;
        data = new HashMap<>(initialCapacity);
    }
}
