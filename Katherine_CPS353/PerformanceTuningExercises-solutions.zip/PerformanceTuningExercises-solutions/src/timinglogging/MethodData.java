package timinglogging;

// Random fun Java trivia: "value classes" are a common use case
// (if you're familiar with C/C++, this is essentially a struct)
// While they aren't hard to write, they have a *lot* of boilerplate
// with toString, getters, final fields, and hashCode/equals
// In Java 17, a new top level type was introduced as a shorthand for these
// classes.
//
// This record is exactly equivalent to a class with a 2-parameter constructor, 
// 2 final fields (numCalls and totalTime), that has appropriate getters, toString,
// and field-based hashCode and equals methods
public record MethodData(int numCalls, long totalTime) {
}
