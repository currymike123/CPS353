package timinglogging;
import java.util.HashMap;
import java.util.Map;

// This is a very simple timing logging framework that just adds up total time in a
// method across all calls, as well as the number of calls. You'll notice it's also not
// thread safe.
//
// Feel free to use this as a building block in checkpoint 8 if you want to use timing
// logging instead of JConsole - you might also track information about the distribution of 
// timing calls (most fast and one or two very slow vs. a high but consistent average), 
// information about the parameters to a method compared to the timing, etc.
public class TimingLogging {

    // log time spent in method
    // & number of calls to the method
    private Map<String, MethodData> dataToLog = new HashMap<>();    
    
    public void recordInfo(String methodName, long totalTimeForCall) {
        MethodData initial = new MethodData(1, totalTimeForCall);
        
        if (dataToLog.containsKey(methodName)) {
            initial = combineData(initial, dataToLog.get(methodName));
        }
        dataToLog.put(methodName, initial);
    }

    private MethodData combineData(MethodData m1, MethodData m2) {
        return new MethodData(m1.numCalls() + m2.numCalls(), m1.totalTime() + m2.totalTime());
    }

    public void printStats() {
        System.out.println(dataToLog);
    }
}
