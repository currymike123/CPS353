package timinglogging;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class TimingLoggingWrapper {

    // This is the advanced version of the wrapper pattern - it creates
    // a dynamic wrapper around objectToWrap that adds timing logging to all
    // of its methods.
    //
    // clazz must be specified due to how generics work in Java - in order to make them
    // backwards-compatible to pre-1.5 version, they're erased at runtime. 
    // This is why you want your APIs to be easy to modify - otherwise, 
    // backwards compatibility is hard!
    public static <T> T createWrapper(Class<T> clazz, T objectToWrap, TimingLogging logging) {
        return (T)Proxy.newProxyInstance(TimingLoggingWrapper.class.getClassLoader(),
                new Class<?>[] {clazz}, new InvocationHandler() {

                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        long start = System.currentTimeMillis();
                        
                        Object result = method.invoke(objectToWrap, args);
                       
                        long end = System.currentTimeMillis();
                        logging.recordInfo(method.getName(), (end - start));
                        return result;
                    }
                    
                });
    }
}
