package exercise1;

import java.util.List;

public class SpeedUp {

	/** 
	 * This method takes the product of each element in array1 with each element in array2,
	 * sums them all together, and returns that result.
	 * 
	 * Assuming you've discovered that this method is a bottleneck in your code, come up with an alternative way to
	 * write the code that may be faster
	 */
	public int thisMethodIsTooSlow(List<Integer> array1, List<Integer> array2) {
		int vectorProduct = 0;
		for (int i = 0; i < array1.size(); i++) {
		    // As a first pass, array1.get(i) can be factored out of the inner loop -
		    // ArrayList.get is pretty fast, but every little bit helps.
		    //
		    // Next, the multiplication can be factored out and done at the end:
            // a*b + a*c = a*(b + c)
            // This is also a small but noticeable improvement (something similar
            // is called Horner's method for polynomial evaluation)
            //
		    // Even better, though, once that's factored out, it turns out
		    // the entire remaining inner loop can be factored out
		    //
		    // Solution in SpeedUpFast for ease of benchmarking this
			for (int j = 0; j < array2.size(); j++) {
				vectorProduct += array1.get(i)*array2.get(j);
			}
		}
		return vectorProduct;
	}
}
