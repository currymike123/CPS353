package exercise2;


public class PerformanceTuning {

    public static void main(String[] args) {
        MysteryClass mystery = new MysteryClass();
        // Surprise! Despite the loop, this is the bottleneck - 
        // this is why it's important to *measure* what method has
        // a bottleneck, rather than guess
        mystery.initialSetup();
        for (int i = 0; i < 100; i++) {
            mystery.doOneTask();
        }
    }
}
