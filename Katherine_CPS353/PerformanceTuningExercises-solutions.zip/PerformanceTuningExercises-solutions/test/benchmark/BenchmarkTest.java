package benchmark;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import exercise1.SpeedUp;
import exercise1.SpeedUpFast;

public class BenchmarkTest {

    private static final int NUM_RUNS = 100;

    @Test // filter out of build.gradle
    public void benchmarkTest() {
        // slow version (baseline)
        SpeedUp slowVersion = new SpeedUp();

        // fast version (under test)
        SpeedUpFast fastVersion = new SpeedUpFast();

        List<Integer> array1 = createFakeData();
        List<Integer> array2 = createFakeData();

        long startTime = System.currentTimeMillis();

        // measure slow version
        for (int i = 0; i < NUM_RUNS; i++) {
            slowVersion.thisMethodIsTooSlow(array1, array2);
        }

        // Use millis, not nanos - avoids accidentally tuning the wrong thing
        long endTime = System.currentTimeMillis();

        long elapsedTimeSlow = endTime - startTime;

        startTime = System.currentTimeMillis();

        // measure fast version
        for (int i = 0; i < NUM_RUNS; i++) {
            fastVersion.thisMethodIsTooSlow(array1, array2);
        }
        
        endTime = System.currentTimeMillis();

        long elapsedTimeFast = endTime - startTime;
        
        // Worth printing out for future debugging, but not strictly 
        // required
        System.out.println("Fast time: " + elapsedTimeFast);
        System.out.println("Slow time: " + elapsedTimeSlow);

        if ((elapsedTimeSlow - elapsedTimeFast) / ((double)elapsedTimeSlow) < 0.1) {
            throw new RuntimeException();
        } 
    }

    // "Representative fake data" can actually be extremely challenging
    // depending on the task. As a first pass, don't choose data
    // designed to show off your solution - you want to mimic real world
    // usage as much as possible.
    // For example, computers can multiply by 2 extremely quickly - choosing all
    // powers of 2 for our fake data would risk being unrepresentative given what
    // we're benchmarking
    private List<Integer> createFakeData() {
        List<Integer> list = new ArrayList<>();
        int numElements = 10_000;
        for (int i = 1; i < numElements; i++) {
            list.add(i);
        }
        return list;
    }
}
