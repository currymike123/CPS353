package exercise2;

public class AddingMachine {
	public long add(int a, int b) {
		return a + b;
	}
}
