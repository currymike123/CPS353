package exercise2;

import java.io.ByteArrayOutputStream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import exercise2.Exercise2.RequestMessage;
import exercise2.Exercise2.ResponseMessage;


public class TestServer {

    @Test
    public void testAdding() throws Exception {
        Server server = new Server();
        
        Request request = new Request(2, 3);
        
        // TODO: send the request to the server
        RequestMessage requestBytes = RequestMessage.newBuilder()
        .setValue1(request.getValue1())
        .setValue2(request.getValue2())
        .build();
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        requestBytes.writeTo(baos);
        baos.close();
        
        // TODO: check that the call was successful
        byte[] values = server.addValues( baos.toByteArray());
        
        // TODO: save the result into 'result'
        ResponseMessage resultMessage = ResponseMessage.parseFrom(values);
        
        int result = resultMessage.getResult();
        Assertions.assertEquals(5, result);
    }
}

