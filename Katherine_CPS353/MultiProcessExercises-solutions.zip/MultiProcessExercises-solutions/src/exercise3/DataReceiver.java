package exercise3;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import exercise2.Exercise2;
import exercise2.Exercise2.ResponseMessage;

public class DataReceiver {

    public static void main(String[] args) throws Exception {

        File file = new File(DataSender.SHARED_FILE_NAME);
        while (!file.exists()) {
            Thread.sleep(100);
        }

        // clean up our data when we're done
        file.deleteOnExit();

        try (FileInputStream in = new FileInputStream(file)) {
            readFileContents(in);
        }
    }

    private static void readFileContents(FileInputStream in) throws IOException {
        ResponseMessage message = Exercise2.ResponseMessage.parseFrom(in);
        System.out.println(message);
    }
}
