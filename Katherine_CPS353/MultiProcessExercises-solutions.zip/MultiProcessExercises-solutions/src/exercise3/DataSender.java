package exercise3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import exercise2.Exercise2.ResponseMessage;

public class DataSender {
	
	public static final String SHARED_FILE_NAME = "multiprocess-exercise1.txt";

	public static void main(String[] args) throws IOException {
		
		// clear out any previous runs
		new File(SHARED_FILE_NAME).delete();
		
		String temporaryFile = "write-sender-data.tmp";
		
		try (FileOutputStream out = new FileOutputStream(temporaryFile)) {
			writeFileContents(out);
		}
		
		// Don't read the data until we're finished writing it
		new File(temporaryFile).renameTo(new File(SHARED_FILE_NAME));
		
	}

	private static void writeFileContents(FileOutputStream out) throws IOException {
		ResponseMessage.newBuilder().setResult(42).build().writeTo(out);
	}
}

