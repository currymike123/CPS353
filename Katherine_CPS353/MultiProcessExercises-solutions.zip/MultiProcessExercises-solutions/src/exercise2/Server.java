package exercise2;

import java.io.ByteArrayOutputStream;

import exercise2.Exercise2.RequestMessage;
import exercise2.Exercise2.ResponseMessage;


public class Server {

    public static final int VERSION = 7;

    public byte[] addValues(byte[] data) throws Exception {
        // TODO: set 'request' to a value read from 'data'
        RequestMessage request = RequestMessage.parseFrom(data);

        int result = request.getValue1() + request.getValue2();

        // TODO: write the result and a success code to a byte array, and return that
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ResponseMessage.newBuilder()
            .setResult(result)
            .build()
            .writeTo(baos);
        baos.close();

        return baos.toByteArray();
    }
}
