package exercise4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import exercise4.Exercise4.TextEditorPreferences;

public class PreferenceStorer {

    public static void main(String[] args) throws IOException {
        // comment this out to see the backcompat in action
        createInitial();
        parseFile();
    }

    private static void parseFile() throws IOException {
        System.out.println(TextEditorPreferences.parseFrom(
                new FileInputStream("exercise4output.txt")));
    }

    private static void createInitial() throws IOException {
        try (FileOutputStream out = new FileOutputStream("exercise4output.txt")) {
            TextEditorPreferences.newBuilder()
                .setFont("Arial")
                .setLightMode(true)
                .build()
                .writeTo(out);
        }
    }
}
