package exercise5;

import exercise5.AddingMachineServiceGrpc.AddingMachineServiceImplBase;
import exercise5.Exercise5.AddingRequest;
import exercise5.Exercise5.AddingResponse;
import io.grpc.stub.StreamObserver;

public class AddingMachineServiceImpl extends AddingMachineServiceImplBase {

    @Override
    public void add(AddingRequest request,
           StreamObserver<AddingResponse> responseObserver) {
        AddingResponse result;
        if (request.hasValue1() && request.hasValue2()) {
            result = AddingResponse.newBuilder()
                    .setResult(request.getValue1() + request.getValue2())
                    .build();
        } else {
            result = AddingResponse.newBuilder()
                    .setErrorMessage("Must specify both value 1 and value 2")
                    .build();
        }
        // Don't use onError!
        responseObserver.onNext(result);
        responseObserver.onCompleted();
    }

}
