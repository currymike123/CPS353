package phoneOrderExample;

import io.grpc.stub.StreamObserver;
import phoneOrderExample.PhoneOrder.PhoneOrderRequest;
import phoneOrderExample.PhoneOrder.PhoneOrderResponse;
import phoneOrderExample.PhoneOrderServiceGrpc.PhoneOrderServiceImplBase;

public class PhoneOrderServiceImpl extends PhoneOrderServiceImplBase {

    @Override
    public void createPhoneOrder(PhoneOrderRequest request,
           StreamObserver<PhoneOrderResponse> responseObserver) {
        PhoneOrderResponse result = PhoneOrderResponse.newBuilder()
                .setOrderNumber("actual server not implemented yet")
                .build();
        responseObserver.onNext(result);
        responseObserver.onCompleted();
    }
}
