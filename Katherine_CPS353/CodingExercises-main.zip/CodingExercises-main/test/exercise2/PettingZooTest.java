package exercise2;

import org.junit.jupiter.api.Test;

public class PettingZooTest {

    @Test
    public void checkZooIsSafe() {
        PettingZoo zoo = new PettingZoo();
        zoo.addAnimalToZoo(new HoneyBadger());
        
        // TODO: make sure this no longer throws an exception
        zoo.visitZoo();
    }
}
