package exercise1;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class TrainTest {

    @Test
    public void checkBuilderPattern() {
        Train example = new Train();
        Person mockPerson = mock(Person.class);
        when(mockPerson.hasTicket()).thenReturn(true);
        
        // TODO: apply the builder pattern to Train so that this 
        // no longer *compiles* (ie, someone trying to use the Train class
        // incorrectly would get alerted to the problem by the compiler)
        example.allAboard();
        example.boardTrain(mockPerson);
    }
}
