package exercise1;

import java.util.ArrayList;
import java.util.List;

public class Train {

	private final List<Person> passengers = new ArrayList<>();
	
	public boolean boardTrain(Person person) {
		if (!person.hasTicket()) {
			return false;
		}
		passengers.add(person);
		return true;
	}
	
	public void allAboard() {
		// TODO no one should be able to board the train after this
	}
	
	public int countPassengers() {
		return passengers.size();
	}
}
