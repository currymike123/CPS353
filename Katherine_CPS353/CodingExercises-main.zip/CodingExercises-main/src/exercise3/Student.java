package exercise3;

public interface Student {

}
