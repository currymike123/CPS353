package exercise3;

public class CSDepartment {
	
	public CSDepartment(StudentDirectory directory) {
		// TODO: register a listener that will welcome new students
	}

	
	private void sendWelcomeEmail(Student s) {
		// send a welcome email to the student
	}
}
