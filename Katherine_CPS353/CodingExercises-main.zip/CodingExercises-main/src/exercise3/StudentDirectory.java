package exercise3;

import java.util.ArrayList;
import java.util.List;

public class StudentDirectory {
	
	private final List<Student> students = new ArrayList<>();
	
	public void enrollStudent(Student s) {
		students.add(s);
		// TODO tell interested departments about the new student
	}

}
