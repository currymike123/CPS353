package exercise3;

public class ITDepartment {
	
	public ITDepartment(StudentDirectory directory) {
		// TODO: register a listener that will create accounts for new students
	}
	
	private void createStudentAccounts(Student s) {
		// get student an email address, OneDrive setup, etc
	}

}
