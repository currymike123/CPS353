package exercise3;

public class CSDepartment {
	
	public CSDepartment(StudentDirectory directory) {
	    // register a listener that will call the private method on this class;
	    // no need to expose that method to StudentDirectory
		directory.addListener(student -> sendWelcomeEmail(student));
	}

	
	private void sendWelcomeEmail(Student s) {
		// send a welcome email to the student
	}
}
