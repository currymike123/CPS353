package exercise3;

public class ITDepartment {
	
	public ITDepartment(StudentDirectory directory) {
	    // register a listener that will call the private method on this class;
        // no need to expose that method to StudentDirectory
        directory.addListener(student -> createStudentAccounts(student));
	}
	
	private void createStudentAccounts(Student s) {
		// get student an email address, OneDrive setup, etc
	}

}
