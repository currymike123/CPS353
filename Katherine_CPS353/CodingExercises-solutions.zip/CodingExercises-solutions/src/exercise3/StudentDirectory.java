package exercise3;

import java.util.ArrayList;
import java.util.List;

public class StudentDirectory {
	
	private final List<Student> students = new ArrayList<>();
	
	// Note that 'final' only applies to the *pointer* - 'listeners' can't 
	// be assigned to point to anything else, but the contents of the 
	// pointee (not an official term) can still change. To get true immutability,
	// all pointers and pointees must be immutable (the ImmutableList class can be helpful for this)
	// In this case, though, we want to be able to add listeners over time
	private final List<StudentListener> listeners = new ArrayList<>();
	
	// Typically, the listener is an inner type for the data class;
	// This isn't required, but it avoids cluttering the type hierarchy for
	// a project, and the type is rarely explicitly used, since it's generally
	// implemented via a lambda
	public static interface StudentListener {
	    public void newStudentEnrolled(Student newStudent);
	}
	
	// "Your ideas are intriguing to me and I would like to subscribe to your newsletter"
	public void addListener(StudentListener listener) {
	    listeners.add(listener);
	}
	
	public void enrollStudent(Student s) {
		students.add(s);
		
		// Let all interested parties know about the new student
		for (StudentListener listener : listeners) {
		    listener.newStudentEnrolled(s);
		}
	}

}
