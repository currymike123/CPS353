package exercise2;

import java.util.ArrayList;
import java.util.List;

public class PettingZoo {

	private List<Animal> animals = new ArrayList<>();
	
	public void addAnimalToZoo(Animal animal) {
	    // Use the wrapper to ensure that all animals are safe
	    // Optionally, the type of 'animals' could be changed to List<SafeAnimal>
	    // Note that we don't have to change visitZoo either way, as SafeAnimal is a subtype
	    // of Animal
		animals.add(new SafeAnimal(animal));
	}
	
	public void visitZoo() {
		for (Animal animal : animals) {
			animal.tryToPet();
		}
	}
	
	public void visitAnimal(int animalIndex) {
		animals.get(animalIndex).tryToPet();
	}
	
}
