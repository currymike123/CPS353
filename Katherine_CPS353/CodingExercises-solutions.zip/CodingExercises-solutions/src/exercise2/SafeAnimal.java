package exercise2;

public class SafeAnimal implements Animal {

    private final Animal wrappedAnimal;
    
    public SafeAnimal(Animal toWrap) {
        this.wrappedAnimal = toWrap;
    }

    @Override
    public boolean tryToPet() {
        // only try to pet a friendly animal
        if (!isFriendly()) {
            return false;
        }
        return wrappedAnimal.tryToPet();
    }

    @Override
    public boolean isFriendly() {
        // no logic to add here, pass through
        // to the wrapped class
        return wrappedAnimal.isFriendly();
    }
}
