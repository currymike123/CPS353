package exercise4;

public class FindMaximumValue {

    // Many options:
    // Stream, Iterator, Iterable, or Paging
    // In this case, since we're iterating through all the values,
    // paging is not really worth the overhead. Stream is an unusual choice
    // since it's largely created as a Java internal type. Iterable is convenient
    // because it supports the shorthand for loop syntax, but technically requires
    // that the input be restartable, which is often but not always the case
    // Some Iterables will not gracefully fail if you restart them (either throwing
    // an exception, or providing incorrect data), so exercise caution if your
    // code does try to traverse an Iterable more than once
	public int findMaximumValue(Iterable<Integer> values) {
		int currentMax = Integer.MIN_VALUE;
		for (int value : values) {
			if (value > currentMax) {
				currentMax = value;
			}
		}
		return currentMax;
	}
}
