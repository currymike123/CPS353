package exercise1;

import java.util.ArrayList;
import java.util.List;

// Builder class: allows the train to change
public class TrainInStation {

private final List<Person> passengers = new ArrayList<>();
    
    public boolean boardTrain(Person person) {
        if (!person.hasTicket()) {
            return false;
        }
        passengers.add(person);
        return true;
    }
    
    // build() method
    public TrainInMotion allAboard() {
        return new TrainInMotion(passengers);
    }
    
}
