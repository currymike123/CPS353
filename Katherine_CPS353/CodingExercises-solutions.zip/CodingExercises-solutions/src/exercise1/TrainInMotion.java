package exercise1;

import java.util.ArrayList;
import java.util.List;

// Immutable class produced by the builder
public class TrainInMotion {

	private final List<Person> passengers;
	
	public TrainInMotion(List<Person> passengers) {
	    // Defensive copy: modifications to passed-in list won't change the train
       this.passengers = new ArrayList<>(passengers);
    }

	// countPassengers belongs on TrainInMotion since a builder
	// should *only* be used to assemble a class - adding other functionality
	// is a sign that the builder is being used as a mutable object, which
	// is what the builder pattern is designed to avoid
    public int countPassengers() {
		return passengers.size();
	}
}
