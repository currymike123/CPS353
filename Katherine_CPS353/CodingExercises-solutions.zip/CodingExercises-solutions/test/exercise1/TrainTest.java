package exercise1;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class TrainTest {

    @Test
    public void checkBuilderPattern() {
        TrainInStation builder = new TrainInStation();
        Person mockPerson = mock(Person.class);
        when(mockPerson.hasTicket()).thenReturn(true);
        
        
        TrainInMotion example = builder.allAboard();
        
        // Our board-after-departing logic no longer compiles - success!
        //
        // Note: design patterns are not a way to add security to code; they
        // don't defend against malicious programmers, and it's still possible
        // to write code that doesn't work even in a codebase that uses design patterns.
        // The goal of using the builder pattern is to avoid someone writing
        // certain types of bugs *by mistake*; while it's possible to still write
        // 'builder.boardTrain(mockPerson)' and have it compile, it's very obvious 
        // that if you're trying to affect 'example', calling a method on the builder
        // after 'example' is created won't work
        example.boardTrain(mockPerson);
    }
}
